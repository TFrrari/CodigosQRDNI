Option Strict On
Option Explicit On
Option Infer Off

' ======================================================================
' Archivo: DniReader.vb
' Rol:    Lector y mapeador de DNI (PDF417) para WinForms en .NET
'
' Connie, escuchá:
' - Este módulo NO crea ni configura controles. Vos ya tenés los TextBox.
' - Acá únicamente parseamos la cadena cruda del escáner (separada por '@')
'   y copiamos cada dato en los TextBox que vos nos digas.
' - Nada corre "solo": SIEMPRE lo invocás desde el Click de tu botón.
'
' Formato esperado (9 partes, separadas por '@'):
'   [0] CódigoTramite      ej: 00719519684
'   [1] Apellido           ej: FERRARI
'   [2] Nombre             ej: TOMAS
'   [3] Sexo               ej: M/F/X
'   [4] NumeroDocumento    ej: 43828097   (lo devolvemos solo con dígitos)
'   [5] Ejemplar           ej: A/B/C...
'   [6] FechaNacimiento    dd/MM/yyyy
'   [7] FechaEmision       dd/MM/yyyy
'   [8] CodigoVerificador  ej: 239
'
' Ejemplo real:
'   00719519684@FERRARI@TOMAS@M@43828097@B@24/03/2002@22/04/2024@239
'
' Uso típico en tu botón:
'   Dim ui = New DniReader.DniUiMap With {
'       .InputCrudo = txtCrudo,          ' opcional si pasás el texto por parámetro
'       .TxtNombre = txtNombre, .TxtApellido = txtApellido, ... (los que quieras)
'   }
'   DniReader.EjecutarDesdeBoton(Me, ui) ' o pasá textoCrudo:=txtCrudo.Text
' ======================================================================

Imports System.Globalization
Imports System.Windows.Forms
Imports System.Text

Public Module DniReader

    ' ---------------------------------------------------------------
    ' Objeto fuertemente tipado para que el resto del código sea claro
    ' ---------------------------------------------------------------
    Public Class DniInfo
        Public Property CodigoTramite As String
        Public Property Apellido As String
        Public Property Nombre As String
        Public Property Sexo As String
        Public Property NumeroDocumento As String     ' lo normalizamos a solo dígitos
        Public Property Ejemplar As String
        Public Property FechaNacimiento As Date?
        Public Property FechaEmision As Date?
        Public Property CodigoVerificador As String
    End Class

    ' -------------------------------------------------------------------
    ' Mapeo a TUS TextBox existentes. Solo referencias, no creamos nada.
    ' Connie: rellená solo lo que uses; lo demás dejalo en Nothing.
    ' -------------------------------------------------------------------
    Public Class DniUiMap
        ' Fuente opcional del texto crudo. Si no lo pasás por parámetro,
        ' lo buscamos acá.
        Public Property InputCrudo As TextBox

        ' Destinos (dejá Nothing si no querés asignar ese campo)
        Public Property TxtCodigoTramite As TextBox
        Public Property TxtApellido As TextBox
        Public Property TxtNombre As TextBox
        Public Property TxtSexo As TextBox
        Public Property TxtNumeroDocumento As TextBox
        Public Property TxtEjemplar As TextBox
        Public Property TxtFechaNacimiento As TextBox
        Public Property TxtFechaEmision As TextBox
        Public Property TxtCodigoVerificador As TextBox
    End Class

    ' -------------------------------------------------------------------
    ' ParsearDni:
    ' - Valida que la cadena exista, separa por '@' y exige 9 campos.
    ' - Limpia espacios, convierte fechas y deja el DNI en solo dígitos.
    ' - Si hay algo clave mal, tira excepción con mensaje claro (vos lo
    '   manejás en el botón y evitás que el usuario quede en la nada).
    ' -------------------------------------------------------------------
    Public Function ParsearDni(ByVal cadena As String) As DniInfo
        If String.IsNullOrWhiteSpace(cadena) Then
            Throw New ArgumentException("La cadena del DNI está vacía o nula.")
        End If

        ' Limpieza mínima para evitar problemas con Enter/fin de línea
        Dim raw As String = cadena.Trim().Replace(vbCr, "").Replace(vbLf, "")

        ' Separación estricta por '@'
        Dim partes As String() = raw.Split("@"c)
        If partes.Length < 9 Then
            Throw New FormatException($"Formato inválido: se esperaban 9 partes y llegaron {partes.Length}. Cadena: '{raw}'")
        End If

        ' Construcción del objeto tipado
        Dim info As New DniInfo With {
            .CodigoTramite = Limpiar(partes(0)),
            .Apellido = Limpiar(partes(1)),
            .Nombre = Limpiar(partes(2)),
            .Sexo = Limpiar(partes(3)),
            .NumeroDocumento = SoloDigitos(Limpiar(partes(4))),
            .Ejemplar = Limpiar(partes(5)),
            .FechaNacimiento = TryParseFecha(Limpiar(partes(6))),
            .FechaEmision = TryParseFecha(Limpiar(partes(7))),
            .CodigoVerificador = Limpiar(partes(8))
        }

        ' Connie, si querés endurecer reglas, habilitá estas dos líneas:
        'If String.IsNullOrEmpty(info.NumeroDocumento) Then
        '    Throw New FormatException("El número de documento está vacío o no se pudo normalizar a dígitos.")
        'End If

        Return info
    End Function

    ' -------------------------------------------------------------------
    ' RellenarControles:
    ' - Copia el contenido de DniInfo a los TextBox que mapeaste.
    ' - Si algún TextBox está en Nothing, lo salta (no rompe).
    ' - Las fechas se formatean "dd/MM/yyyy" por defecto.
    ' -------------------------------------------------------------------
    Public Sub RellenarControles(ByVal ui As DniUiMap, ByVal info As DniInfo, Optional ByVal formatoFecha As String = "dd/MM/yyyy")
        If ui Is Nothing OrElse info Is Nothing Then Exit Sub

        Asignar(ui.TxtCodigoTramite, info.CodigoTramite)
        Asignar(ui.TxtApellido, info.Apellido)
        Asignar(ui.TxtNombre, info.Nombre)
        Asignar(ui.TxtSexo, info.Sexo)
        Asignar(ui.TxtNumeroDocumento, info.NumeroDocumento)
        Asignar(ui.TxtEjemplar, info.Ejemplar)

        ' Fechas: si hay valor, se formatean; si no, quedan vacías
        Asignar(ui.TxtFechaNacimiento, If(info.FechaNacimiento.HasValue, info.FechaNacimiento.Value.ToString(formatoFecha, CultureInfo.GetCultureInfo("es-AR")), ""))
        Asignar(ui.TxtFechaEmision, If(info.FechaEmision.HasValue, info.FechaEmision.Value.ToString(formatoFecha, CultureInfo.GetCultureInfo("es-AR")), ""))

        Asignar(ui.TxtCodigoVerificador, info.CodigoVerificador)
    End Sub

    ' -------------------------------------------------------------------
    ' EjecutarDesdeBoton:
    ' - Esta es la única entrada que vas a llamar desde tu botón.
    ' - Toma el texto del parámetro o, si no lo pasás, de ui.InputCrudo.
    ' - onOk/onError te permiten actualizar un Label/Status sin MessageBox.
    ' -------------------------------------------------------------------
    Public Sub EjecutarDesdeBoton(ByVal form As Form,
                                  ByVal ui As DniUiMap,
                                  Optional ByVal textoCrudo As String = Nothing,
                                  Optional ByVal onOk As Action(Of DniInfo) = Nothing,
                                  Optional ByVal onError As Action(Of String) = Nothing)

        Try
            ' 1) Seleccionamos la fuente del texto
            Dim fuente As String = If(Not String.IsNullOrWhiteSpace(textoCrudo),
                                      textoCrudo,
                                      If(ui IsNot Nothing AndAlso ui.InputCrudo IsNot Nothing, ui.InputCrudo.Text, Nothing))

            ' 2) Parseamos y validamos
            Dim info As DniInfo = ParsearDni(fuente)

            ' 3) Copiamos a los TextBox mapeados
            RellenarControles(ui, info)

            ' 4) Avisá éxito (si te pasaron callback)
            If onOk IsNot Nothing Then onOk.Invoke(info)

        Catch ex As Exception
            ' Avisá error de forma no intrusiva (sin frenar la UI)
            If onError IsNot Nothing Then
                onError.Invoke(ex.Message)
            End If
            ' Si preferís modal, descomentá lo de abajo:
            ' MessageBox.Show(form, ex.Message, "Error al leer DNI", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' =========================
    ' Helpers internos (privado)
    ' =========================

    ' Asigna .Text si el TextBox existe; si no, ignora
    Private Sub Asignar(ByVal tb As TextBox, ByVal valor As String)
        If tb Is Nothing Then Exit Sub
        tb.Text = If(valor, String.Empty)
    End Sub

    ' Recorta y normaliza espacios; si viene Nothing, devolvemos vacío
    Private Function Limpiar(ByVal s As String) As String
        If s Is Nothing Then Return String.Empty
        Return s.Trim()
    End Function

    ' Devuelve solo los dígitos (para DNI sin puntos/espacios)
    Private Function SoloDigitos(ByVal s As String) As String
        If String.IsNullOrEmpty(s) Then Return String.Empty
        Dim r As New StringBuilder(s.Length)
        For Each c As Char In s
            If Char.IsDigit(c) Then r.Append(c)
        Next
        Return r.ToString()
    End Function

    ' Intenta parsear fechas con formato argentino; si no puede, devuelve Nothing
    Private Function TryParseFecha(ByVal s As String) As Date?
        If String.IsNullOrWhiteSpace(s) Then Return Nothing

        Dim dt As Date
        ' Principal: dd/MM/yyyy (es-AR)
        If Date.TryParseExact(s, "dd/MM/yyyy", CultureInfo.GetCultureInfo("es-AR"), DateTimeStyles.None, dt) Then
            Return dt
        End If

        ' Alternativas razonables por si el emisor cambia formato
        Dim formatos() As String = {"d/M/yyyy", "dd-MM-yyyy", "d-M-yyyy", "yyyy-MM-dd"}
        For Each f In formatos
            If Date.TryParseExact(s, f, CultureInfo.InvariantCulture, DateTimeStyles.None, dt) Then
                Return dt
            End If
        Next

        ' Último intento: parseo general (culture-invariant). Si falla, Nothing.
        If Date.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.None, dt) Then
            Return dt
        End If

        Return Nothing
    End Function

End Module
