Option Strict On
Option Explicit On
Option Infer Off

' ======================================================================
' Archivo: DniSqlHelper.vb
'
' Connie, acá tenés un helper ADO.NET NEUTRO que:
'   - NO ejecuta nada: solo arma DbCommand listos para usar.
'   - Te deja configurar:
'       * Provider ADO.NET (Oracle, OleDb, SqlClient, etc.)
'       * Nombre de la tabla y columnas
'       * Prefijo de parámetro (@ o :) para evitar incompatibilidades
'   - Incluye:
'       * BuildSelectPorDni   -> SELECT * ... WHERE DNI = :dni/@dni
'       * BuildExistsPorDni   -> SELECT COUNT(1) ... WHERE DNI = :dni/@dni
'       * BuildInsert         -> INSERT parametrizado (todos los campos)
'       * BuildUpdatePorDni   -> UPDATE por DNI (todos los campos)
'
' Uso tipo (en tu botón "Guardar"):
'   Dim cfg As New SqlConfig With {
'       .ProviderInvariantName = "Oracle.ManagedDataAccess.Client",
'       .ParametroPrefijo = ":",          ' ":" para Oracle, "@" para SQL/OleDb (ajustá según provider)
'       .NombreTabla = "PACIENTES",
'       .Col_Dni = "DNI", .Col_Nombre = "NOMBRE", ... (el resto)
'   }
'   Dim factory = DbProviderFactories.GetFactory(cfg.ProviderInvariantName)
'   Using conn = factory.CreateConnection()
'       conn.ConnectionString = "TU_CONEXION"
'       conn.Open()
'
'       ' 1) ¿Existe?
'       Dim cmdExists = BuildExistsPorDni(cfg, conn, dni)
'       Dim exists As Integer = CInt(cmdExists.ExecuteScalar())
'
'       ' 2) Según exista, armás UPDATE o INSERT
'       Dim cmd As DbCommand = If(exists > 0, BuildUpdatePorDni(cfg, conn, info), BuildInsert(cfg, conn, info))
'       'cmd.ExecuteNonQuery() ' <- lo ejecutás si corresponde
'   End Using
' ======================================================================

Imports System.Data
Imports System.Data.Common
Imports System.Text

Public Module DniSqlHelper

    ' -------------------------------------------------------------
    ' Todo lo configurable lo centralizamos acá para que no busques
    ' nombres dispersos por el código.
    ' -------------------------------------------------------------
    Public Class SqlConfig
        ' Provider ADO.NET
        '  - Oracle:  "Oracle.ManagedDataAccess.Client"
        '  - OleDb:   "System.Data.OleDb"
        '  - SQLSrv:  "System.Data.SqlClient" (Full Framework)
        Public Property ProviderInvariantName As String = "Oracle.ManagedDataAccess.Client"

        ' Prefijo de parámetro:
        '  - Oracle: ":"   (recomendado)
        '  - SQL/OleDb: "@"
        Public Property ParametroPrefijo As String = ":"

        ' Tabla destino
        Public Property NombreTabla As String = "PACIENTES"

        ' Columnas alineadas con DniReader.DniInfo
        Public Property Col_Dni As String = "DNI"
        Public Property Col_Apellido As String = "APELLIDO"
        Public Property Col_Nombre As String = "NOMBRE"
        Public Property Col_Sexo As String = "SEXO"
        Public Property Col_Ejemplar As String = "EJEMPLAR"
        Public Property Col_FechaNacimiento As String = "FECHA_NAC"
        Public Property Col_FechaEmision As String = "FECHA_EMI"
        Public Property Col_CodTramite As String = "COD_TRAMITE"
        Public Property Col_CodVerificador As String = "COD_VERIF"
    End Class

    ' -------------------------------------------------------------
    ' SELECT por DNI -> trae la fila completa (NO ejecuta)
    '  - Usalo con ExecuteReader() si querés leer columnas puntuales.
    ' -------------------------------------------------------------
    Public Function BuildSelectPorDni(ByVal cfg As SqlConfig, ByVal conn As DbConnection, ByVal dni As String) As DbCommand
        ValidarCfgYConn(cfg, conn)
        If String.IsNullOrWhiteSpace(dni) Then Throw New ArgumentException("DNI vacío.", NameOf(dni))

        Dim pDni As String = cfg.ParametroPrefijo & "dni"

        Dim cmd As DbCommand = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = $"SELECT * FROM {cfg.NombreTabla} WHERE {cfg.Col_Dni} = {pDni}"
        AddParam(cmd, pDni, dni)
        Return cmd
    End Function

    ' -------------------------------------------------------------
    ' EXISTS por DNI -> devuelve COUNT(1) (NO ejecuta)
    '  - Ideal para decidir si hacés INSERT o UPDATE.
    '  - Ejecutalo con ExecuteScalar() y compará > 0.
    ' -------------------------------------------------------------
    Public Function BuildExistsPorDni(ByVal cfg As SqlConfig, ByVal conn As DbConnection, ByVal dni As String) As DbCommand
        ValidarCfgYConn(cfg, conn)
        If String.IsNullOrWhiteSpace(dni) Then Throw New ArgumentException("DNI vacío.", NameOf(dni))

        Dim pDni As String = cfg.ParametroPrefijo & "dni"

        Dim cmd As DbCommand = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = $"SELECT COUNT(1) FROM {cfg.NombreTabla} WHERE {cfg.Col_Dni} = {pDni}"
        AddParam(cmd, pDni, dni)
        Return cmd
    End Function

    ' -------------------------------------------------------------
    ' INSERT completo (NO ejecuta)
    '  - Arma un INSERT con todos los campos del DNI.
    '  - Recordá que info viene del DniReader (ParsearDni).
    ' -------------------------------------------------------------
    Public Function BuildInsert(ByVal cfg As SqlConfig, ByVal conn As DbConnection, ByVal info As DniReader.DniInfo) As DbCommand
        ValidarCfgYConn(cfg, conn)
        If info Is Nothing Then Throw New ArgumentNullException(NameOf(info))

        ' Armamos "INSERT INTO tabla (col1,col2,...) VALUES (:p1,:p2,...)"
        Dim cols As String() = {
            cfg.Col_Dni, cfg.Col_Apellido, cfg.Col_Nombre, cfg.Col_Sexo, cfg.Col_Ejemplar,
            cfg.Col_FechaNacimiento, cfg.Col_FechaEmision, cfg.Col_CodTramite, cfg.Col_CodVerificador
        }
        Dim pars As String() = P(cfg, "dni", "ap", "nom", "sex", "eje", "fn", "fe", "tram", "verif")

        Dim sql As New StringBuilder("INSERT INTO ")
        sql.Append(cfg.NombreTabla).Append(" (").Append(String.Join(",", cols)).Append(") VALUES (")
        sql.Append(String.Join(",", pars)).Append(")")

        Dim cmd As DbCommand = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = sql.ToString()

        AddParam(cmd, pars(0), info.NumeroDocumento)
        AddParam(cmd, pars(1), info.Apellido)
        AddParam(cmd, pars(2), info.Nombre)
        AddParam(cmd, pars(3), info.Sexo)
        AddParam(cmd, pars(4), info.Ejemplar)
        AddParam(cmd, pars(5), If(info.FechaNacimiento, CType(DBNull.Value, Object)))
        AddParam(cmd, pars(6), If(info.FechaEmision, CType(DBNull.Value, Object)))
        AddParam(cmd, pars(7), info.CodigoTramite)
        AddParam(cmd, pars(8), info.CodigoVerificador)

        Return cmd
    End Function

    ' -------------------------------------------------------------
    ' UPDATE por DNI (NO ejecuta)
    '  - Actualiza todos los campos de la fila con ese DNI.
    ' -------------------------------------------------------------
    Public Function BuildUpdatePorDni(ByVal cfg As SqlConfig, ByVal conn As DbConnection, ByVal info As DniReader.DniInfo) As DbCommand
        ValidarCfgYConn(cfg, conn)
        If info Is Nothing Then Throw New ArgumentNullException(NameOf(info))

        Dim pAp As String = P1(cfg, "ap")
        Dim pNom As String = P1(cfg, "nom")
        Dim pSex As String = P1(cfg, "sex")
        Dim pEje As String = P1(cfg, "eje")
        Dim pFn As String = P1(cfg, "fn")
        Dim pFe As String = P1(cfg, "fe")
        Dim pTram As String = P1(cfg, "tram")
        Dim pVerif As String = P1(cfg, "verif")
        Dim pDni As String = P1(cfg, "dni")

        Dim cmd As DbCommand = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText =
$"UPDATE {cfg.NombreTabla} SET
   {cfg.Col_Apellido}        = {pAp},
   {cfg.Col_Nombre}          = {pNom},
   {cfg.Col_Sexo}            = {pSex},
   {cfg.Col_Ejemplar}        = {pEje},
   {cfg.Col_FechaNacimiento} = {pFn},
   {cfg.Col_FechaEmision}    = {pFe},
   {cfg.Col_CodTramite}      = {pTram},
   {cfg.Col_CodVerificador}  = {pVerif}
 WHERE {cfg.Col_Dni}         = {pDni}"

        AddParam(cmd, pAp, info.Apellido)
        AddParam(cmd, pNom, info.Nombre)
        AddParam(cmd, pSex, info.Sexo)
        AddParam(cmd, pEje, info.Ejemplar)
        AddParam(cmd, pFn, If(info.FechaNacimiento, CType(DBNull.Value, Object)))
        AddParam(cmd, pFe, If(info.FechaEmision, CType(DBNull.Value, Object)))
        AddParam(cmd, pTram, info.CodigoTramite)
        AddParam(cmd, pVerif, info.CodigoVerificador)
        AddParam(cmd, pDni, info.NumeroDocumento)

        Return cmd
    End Function

    ' =========================
    ' Helpers ADO.NET internos
    ' =========================

    ' Valida configuración y conexión (mensajes claros)
    Private Sub ValidarCfgYConn(ByVal cfg As SqlConfig, ByVal conn As DbConnection)
        If cfg Is Nothing Then Throw New ArgumentNullException(NameOf(cfg), "Config nula. Revisá dónde instanciás SqlConfig.")
        If conn Is Nothing Then Throw New ArgumentNullException(NameOf(conn), "Conexión nula. Creá la conexión con el factory del provider.")
        If String.IsNullOrWhiteSpace(cfg.ParametroPrefijo) Then Throw New ArgumentException("ParametroPrefijo vacío. Usá ':' para Oracle o '@' para SQL/OleDb.")
        If String.IsNullOrWhiteSpace(cfg.NombreTabla) Then Throw New ArgumentException("NombreTabla vacío. Definilo en SqlConfig.")
        If String.IsNullOrWhiteSpace(cfg.Col_Dni) Then Throw New ArgumentException("Col_Dni vacío. Definilo en SqlConfig.")
    End Sub

    ' Crea y agrega parámetro al DbCommand, respetando el prefijo elegido
    Private Sub AddParam(ByVal cmd As DbCommand, ByVal nombreConPrefijo As String, ByVal value As Object)
        Dim p As DbParameter = cmd.CreateParameter()
        ' OJO: algunos providers esperan ParameterName SIN prefijo;
        ' otros lo toleran con prefijo. Para máxima compatibilidad:
        ' - Guardamos el nombre CON prefijo en el SQL.
        ' - En el parámetro, le asignamos el nombre SIN prefijo si detectamos ":" o "@".
        Dim cleanName As String = nombreConPrefijo.TrimStart(":"c, "@"c)
        p.ParameterName = cleanName
        p.Value = If(value, DBNull.Value)
        cmd.Parameters.Add(p)
    End Sub

    ' Genera nombres de parámetros con el prefijo elegido, en lote
    Private Function P(ByVal cfg As SqlConfig, ParamArray ByVal names() As String) As String()
        Dim result(names.Length - 1) As String
        For i As Integer = 0 To names.Length - 1
            result(i) = cfg.ParametroPrefijo & names(i)
        Next
        Return result
    End Function

    ' Genera un nombre de parámetro con prefijo
    Private Function P1(ByVal cfg As SqlConfig, ByVal name As String) As String
        Return cfg.ParametroPrefijo & name
    End Function

End Module
