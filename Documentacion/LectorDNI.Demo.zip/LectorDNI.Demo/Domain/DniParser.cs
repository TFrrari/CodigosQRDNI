using System;
using System.Text.RegularExpressions;

namespace LectorDNI.Demo.Domain
{
    public static class DniParser
    {
        static readonly Regex Solo7a9 = new(@"^\d{7,9}$");

        public static DniParsed Parse(string? raw)
        {
            var r = new DniParsed();
            if (string.IsNullOrWhiteSpace(raw)) return r;

            var text = raw.Trim().Replace("\r", "").Replace("\n", "");
            var parts = text.Split('@', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            int dniIdx = -1;
            for (int i = 0; i < parts.Length; i++)
            {
                if (Solo7a9.IsMatch(parts[i]))
                {
                    r.DNI = parts[i];
                    dniIdx = i;
                    break;
                }
            }

            if (dniIdx >= 1) r.Apellido = parts[dniIdx - 1].Trim();
            if (dniIdx >= 0 && dniIdx + 1 < parts.Length) r.Nombre = parts[dniIdx + 1].Trim();

            for (int i = Math.Max(0, dniIdx - 3); i <= Math.Min(parts.Length - 1, dniIdx + 6); i++)
            {
                var t = parts[i].Trim().ToUpperInvariant();
                if (t == "M" || t == "F") { r.Sexo = t; break; }
            }
            for (int i = Math.Max(0, dniIdx - 3); i <= Math.Min(parts.Length - 1, dniIdx + 8); i++)
            {
                var t = parts[i].Trim().ToUpperInvariant();
                if (t is "ARG" or "ARGENTINA") { r.Nacionalidad = "ARGENTINA"; break; }
            }
            return r;
        }
    }
}
