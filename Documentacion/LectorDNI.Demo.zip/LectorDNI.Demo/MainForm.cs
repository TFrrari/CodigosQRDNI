using System;
using System.Drawing;
using System.Windows.Forms;
using LectorDNI.Demo.Domain;

namespace LectorDNI.Demo
{
    public class MainForm : Form
    {
        // Controles
        TextBox txtBuffer = new() { Multiline = true, ReadOnly = true, Height = 70, Dock = DockStyle.Fill };
        Button btnListo = new() { Text = "Listo para escanear" };
        Button btnProcesar = new() { Text = "Procesar DNI" };

        TextBox txtDNI = new();
        TextBox txtApellido = new();
        TextBox txtNombre = new();
        TextBox txtSexo = new();
        TextBox txtNacionalidad = new();

        Button btnLimpiar = new() { Text = "Limpiar" };
        Label lblEstado = new() { AutoSize = true, ForeColor = Color.DimGray };

        Timer calmTimer = new() { Interval = 400 };

        public MainForm()
        {
            Text = "Lector DNI – Demo (manual)";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(760, 420);

            var grid = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 9,
                Padding = new Padding(10)
            };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

            // Fila 0: buffer y botones
            grid.Controls.Add(new Label { Text = "Buffer (pegar aquí la cadena del DNI)", AutoSize = true }, 0, 0);
            grid.SetColumnSpan(txtBuffer, 3);
            grid.Controls.Add(txtBuffer, 1, 0);
            grid.Controls.Add(btnListo, 0, 1);
            grid.Controls.Add(btnProcesar, 1, 1);
            grid.Controls.Add(btnLimpiar, 2, 1);

            // Datos
            grid.Controls.Add(new Label { Text = "DNI", AutoSize = true }, 0, 2);
            grid.Controls.Add(txtDNI, 1, 2);
            grid.Controls.Add(new Label { Text = "Apellido", AutoSize = true }, 2, 2);
            grid.Controls.Add(txtApellido, 3, 2);

            grid.Controls.Add(new Label { Text = "Nombre", AutoSize = true }, 0, 3);
            grid.Controls.Add(txtNombre, 1, 3);
            grid.Controls.Add(new Label { Text = "Sexo", AutoSize = true }, 2, 3);
            grid.Controls.Add(txtSexo, 3, 3);

            grid.Controls.Add(new Label { Text = "Nacionalidad", AutoSize = true }, 0, 4);
            grid.Controls.Add(txtNacionalidad, 1, 4);

            grid.SetColumnSpan(lblEstado, 4);
            grid.Controls.Add(lblEstado, 0, 6);

            Controls.Add(grid);

            // Eventos
            Load += (_, __) => PrepararEscaneo();
            btnListo.Click += (_, __) => PrepararEscaneo();
            btnProcesar.Click += (_, __) => ProcesarBuffer();
            btnLimpiar.Click += (_, __) => LimpiarTodo();

            txtBuffer.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true; // evita el beep
                    ProcesarBuffer();
                }
            };
            txtBuffer.TextChanged += (_, __) => { calmTimer.Stop(); calmTimer.Start(); };
            calmTimer.Tick += (_, __) => { calmTimer.Stop(); ProcesarBuffer(); };
        }

        void PrepararEscaneo()
        {
            txtBuffer.ReadOnly = false;
            txtBuffer.Clear();
            txtBuffer.Focus();
            lblEstado.Text = "Pegá la cadena del DNI y presioná Enter (o esperá 0.4s).";
        }

        void LimpiarTodo()
        {
            txtBuffer.ReadOnly = false;
            txtBuffer.Clear();
            txtDNI.Clear();
            txtApellido.Clear();
            txtNombre.Clear();
            txtSexo.Clear();
            txtNacionalidad.Clear();
            lblEstado.Text = "Limpiado.";
            txtBuffer.Focus();
        }

        void ProcesarBuffer()
        {
            txtBuffer.ReadOnly = true;
            var parsed = DniParser.Parse(txtBuffer.Text);

            txtDNI.Text = parsed.DNI;
            txtApellido.Text = parsed.Apellido;
            txtNombre.Text = parsed.Nombre;
            txtSexo.Text = parsed.Sexo;
            txtNacionalidad.Text = parsed.Nacionalidad;

            lblEstado.Text = string.IsNullOrEmpty(parsed.DNI)
                ? "No se detectó DNI válido. Verificá la cadena."
                : "DNI parseado OK. Podés limpiar o pegar otro.";
        }
    }
}
