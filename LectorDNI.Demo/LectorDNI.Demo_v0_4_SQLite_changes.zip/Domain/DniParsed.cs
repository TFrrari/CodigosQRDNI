using System;

namespace LectorDNI.Demo.Domain
{
    /// <summary>
    /// Modelo con los datos parseados del DNI (v0.4).
    /// </summary>
    public class DniParsed
    {
        public string DNI { get; set; } = string.Empty;
        public string Apellido { get; set; } = string.Empty;
        public string Nombre { get; set; } = string.Empty;
        /// <summary>'M'/'F'/'X'</summary>
        public string Sexo { get; set; } = string.Empty;

        /// <summary>Fecha tal cual llega (dd-MM-yyyy o dd/MM/yyyy)</summary>
        public string FechaNacimientoRaw { get; set; } = string.Empty;

        /// <summary>Fecha parseada (si se pudo interpretar)</summary>
        public DateTime? FechaNacimiento { get; set; }

        /// <summary>Nacionalidad si se detecta; la UI pone 'ARGENTINA' por defecto si viene vacío.</summary>
        public string Nacionalidad { get; set; } = string.Empty;
    }
}
