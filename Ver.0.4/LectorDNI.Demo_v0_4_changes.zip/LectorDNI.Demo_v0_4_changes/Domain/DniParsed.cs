using System;

namespace LectorDNI.Demo.Domain
{
    /// <summary>
    /// Modelo con los datos parseados del DNI.
    /// v0.4: agrega FechaNacimientoRaw, FechaNacimiento (nullable) y Nacionalidad.
    /// </summary>
    public class DniParsed
    {
        /// <summary>DNI sin puntos (solo dígitos).</summary>
        public string DNI { get; set; } = string.Empty;

        public string Apellido { get; set; } = string.Empty;
        public string Nombre   { get; set; } = string.Empty;

        /// <summary>'M' / 'F' / 'X'</summary>
        public string Sexo     { get; set; } = string.Empty;

        /// <summary>Fecha tal cual llega en la cadena (ej.: 24-03-2002 o 24/03/2002)</summary>
        public string FechaNacimientoRaw { get; set; } = string.Empty;

        /// <summary>Fecha parseada si se pudo interpretar (dd/MM/yyyy o dd-MM-yyyy).</summary>
        public DateTime? FechaNacimiento { get; set; }

        /// <summary>Nacionalidad si el QR la sugiere (ARG/ARGENTINA). Si queda vacío, la UI pone 'ARGENTINA'.</summary>
        public string Nacionalidad { get; set; } = string.Empty;
    }
}
