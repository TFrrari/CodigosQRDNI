using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using LectorDNI.Demo.Domain;

namespace LectorDNI.Demo
{
    /// <summary>
    /// v0.4: mejoras de parser, mensajes de estado y default de Nacionalidad (ARGENTINA si no viene).
    /// Sin dependencias de BD para que puedas integrar a mano o pegar sobre tu proyecto actual.
    /// </summary>
    public class MainForm : Form
    {
        // Controles mínimos
        TextBox txtBuffer = new() { Multiline = true, ReadOnly = false, Height = 70, Dock = DockStyle.Fill };
        Button btnListo = new() { Text = "Listo para escanear" };
        Button btnProcesar = new() { Text = "Procesar DNI" };
        Button btnLimpiar = new() { Text = "Limpiar" };

        TextBox txtDNI = new();
        TextBox txtApellido = new();
        TextBox txtNombre = new();
        TextBox txtSexo = new();
        TextBox txtFechaNacimiento = new();
        TextBox txtNacionalidad = new();

        Label lblEstado = new() { AutoSize = true, ForeColor = Color.DimGray };
        private readonly System.Windows.Forms.Timer calmTimer = new() { Interval = 400 };

        public MainForm()
        {
            Text = "Lector DNI – Demo v0.4";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(820, 480);

            var grid = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 10,
                Padding = new Padding(10)
            };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

            // Buffer + botones
            grid.Controls.Add(new Label { Text = "Buffer (pegá o escaneá acá):", AutoSize = true }, 0, 0);
            grid.SetColumnSpan(txtBuffer, 3);
            grid.Controls.Add(txtBuffer, 1, 0);

            grid.Controls.Add(btnListo, 0, 1);
            grid.Controls.Add(btnProcesar, 1, 1);
            grid.Controls.Add(btnLimpiar, 2, 1);

            // Campos
            grid.Controls.Add(new Label { Text = "DNI", AutoSize = true }, 0, 2);
            grid.Controls.Add(txtDNI, 1, 2);
            grid.Controls.Add(new Label { Text = "Apellido", AutoSize = true }, 2, 2);
            grid.Controls.Add(txtApellido, 3, 2);

            grid.Controls.Add(new Label { Text = "Nombre", AutoSize = true }, 0, 3);
            grid.Controls.Add(txtNombre, 1, 3);
            grid.Controls.Add(new Label { Text = "Sexo", AutoSize = true }, 2, 3);
            grid.Controls.Add(txtSexo, 3, 3);

            grid.Controls.Add(new Label { Text = "Fecha Nac.", AutoSize = true }, 0, 4);
            grid.Controls.Add(txtFechaNacimiento, 1, 4);
            grid.Controls.Add(new Label { Text = "Nacionalidad", AutoSize = true }, 2, 4);
            grid.Controls.Add(txtNacionalidad, 3, 4);

            grid.SetColumnSpan(lblEstado, 4);
            grid.Controls.Add(lblEstado, 0, 6);

            Controls.Add(grid);

            // Eventos
            Load += (_, __) => PrepararEscaneo();
            btnListo.Click += (_, __) => PrepararEscaneo();
            btnProcesar.Click += (_, __) => ProcesarBuffer();
            btnLimpiar.Click += (_, __) => LimpiarTodo();

            txtBuffer.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    ProcesarBuffer();
                }
            };
            txtBuffer.TextChanged += (_, __) => { calmTimer.Stop(); calmTimer.Start(); };
            calmTimer.Tick += (_, __) => { calmTimer.Stop(); ProcesarBuffer(); };

            // Solo lectura para campos provenientes del DNI
            txtDNI.ReadOnly = true;
            txtApellido.ReadOnly = true;
            txtNombre.ReadOnly = true;
            txtSexo.ReadOnly = true;
        }

        void PrepararEscaneo()
        {
            txtBuffer.ReadOnly = false;
            txtBuffer.Clear();
            lblEstado.Text = "Escaneá el DNI y presioná Enter (o esperá 0.4s).";
            txtBuffer.Focus();
        }

        void LimpiarTodo()
        {
            txtBuffer.ReadOnly = false;
            txtBuffer.Clear();
            txtDNI.Clear();
            txtApellido.Clear();
            txtNombre.Clear();
            txtSexo.Clear();
            txtFechaNacimiento.Clear();
            txtNacionalidad.Clear();
            lblEstado.Text = "Limpiado.";
            txtBuffer.Focus();
        }

        void ProcesarBuffer()
        {
            var raw = txtBuffer.Text;
            if (string.IsNullOrWhiteSpace(raw))
            {
                lblEstado.Text = "Buffer vacío.";
                return;
            }

            txtBuffer.ReadOnly = true;
            var parsed = DniParser.Parse(raw);

            txtDNI.Text = parsed.DNI;
            txtApellido.Text = parsed.Apellido;
            txtNombre.Text = parsed.Nombre;
            txtSexo.Text = parsed.Sexo;

            // Fecha: mostramos dd/MM/yyyy si tenemos DateTime; sino, lo crudo
            txtFechaNacimiento.Text =
                parsed.FechaNacimiento.HasValue ? parsed.FechaNacimiento.Value.ToString("dd/MM/yyyy")
                                                : parsed.FechaNacimientoRaw;

            // Nacionalidad: si no vino desde el QR, default ARGENTINA en UI (pedido v0.4)
            txtNacionalidad.Text = string.IsNullOrWhiteSpace(parsed.Nacionalidad) ? "ARGENTINA"
                                                                                  : parsed.Nacionalidad;

            lblEstado.Text = string.IsNullOrEmpty(parsed.DNI)
                ? "No se detectó DNI válido. Verificá la cadena."
                : "DNI parseado OK.";
        }
    }
}
